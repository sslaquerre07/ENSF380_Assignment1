import React from 'react'

function Footer(){
    return(
        <footer>
            <p>Copyright by Sam Laquerre Robert Meyer</p>
        </footer>
    );
}
export default Footer;