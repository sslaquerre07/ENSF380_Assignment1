const reviews = [ 
    { 
      productName: "Product A", 
      customerName: "John Doe", 
      reviewContent: "Great product, highly recommended!", 
      stars: 5 
    }, 
    { 
      productName: "Product B", 
      customerName: "Jane Smith", 
      reviewContent: "Good quality, fast shipping.", 
      stars: 4 
    }, 
    { 
      productName: "Product C", 
      customerName: "Alice Johnson", 
      reviewContent: "Satisfied with the purchase.", 
      stars: 4 
    }, 
    { 
      productName: "Product A", 
      customerName: "Bob Brown", 
      reviewContent: "Could be better.", 
      stars: 3 
    } 
  ]; 
export default reviews;