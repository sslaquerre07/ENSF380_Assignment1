// reportWebVitals.js
function reportWebVitals(metric) {
    console.log(metric);
}
export default reportWebVitals;
  